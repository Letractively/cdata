<?php


class Relation {
	
	var $model = array();
	var $object_table = array();
	var $form;
	
	function Relation(){
		
		$this->object_table = array(			
			"db" => array(
				"name" => "Database",
				"table" => "db",
				"id" => "db_id",
				"pathName" => "name"
				),
			"patient" => array(
				"name" => "Patient",
				"table" => "patient",
				"id" => "patient_id",
				"pathName" => "code"
				),
			"pform" => array(
				"name" => "Form",
				"table" => "pform",
				"id" => "pform_id",
				"pathName" => "title"
				),
			"file" => array(
				"name" => "File",
				"table" => "file",
				"id" => "file_id",
				"pathName" => "name"
				),
			"page" => array(
				"name" => "Page",
				"table" => "page",
				"id" => "page_id",
				"pathName" => "title"
				),
			"link" => array(
				"name" => "Link",
				"table" => "link",
				"id" => "link_id",
				"pathName" => "title"
				),
			"project" => array(
				"name" => "Project",
				"table" => "project",
				"id" => "project_id",
				"pathName" => "title"
				),
			"todo" => array(
				"name" => "Todo",
				"table" => "todo",
				"id" => "todo_id",
				"pathName" => "title"
				),
			"folder" => array(
				"name" => "Folder",
				"table" => "folder",
				"id" => "folder_id",
				"pathName" => "name"
				),
			"event" => array(
				"name" => "Event",
				"table" => "event",
				"id" => "event_id",
				"pathName" => "title"
				)
		);
		
		$this->model = array(
			"root" => array(
				"db" => array(
					"card" => "many"
					),
				"project" => array(
					"card" => "many"
					),
				"folder" => array(
					"card" => "many"
					),
				"page" => array(
					"card" => "many"
					),
				"link" => array(
					"card" => "many"
					),	
				"file" => array(
					"card" => "many"
					),
				"event" => array(
					"card" => "many"
					)						
				),
			"db" => array(
				"patient" => array(
					"card" => "many"
					),	
				"project" => array(
					"card" => "many"
					),
				"todo" => array(
					"card" => "many"
					),
				"folder" => array(
					"card" => "many"
					),	
				"file" => array(
					"card" => "many"
					),
				"link" => array(
					"card" => "many"
					),	
				"page" => array(
					"card" => "many"
					),
				"event" => array(
					"card" => "many"
					)					
				),	
			"patient" => array(	
				"folder" => array(
					"card" => "many"
					),							
				"pform" => array(
					"card" => "many"
					),	
				"project" => array(
					"card" => "many"
					),
				"todo" => array(
					"card" => "many"
					),					
				"file" => array(
					"card" => "many"
					),
				"page" => array(
					"card" => "many"
					),
				"link" => array(
					"card" => "many"
					),	
				"event" => array(
					"card" => "many"
					)		
				),
			"pform" => array(
				"pform" => array(
					"card" => "many"
					),
				"folder" => array(
					"card" => "many"
					),
				"file" => array(
					"card" => "many"
					),
				"todo" => array(
					"card" => "many"
					),
				"link" => array(
					"card" => "many"
					),
				"page" => array(
					"card" => "many"
					),	
				"event" => array(
					"card" => "many"
					)			
				),
			"file" => array(
				"folder" => array(
					"card" => "many"
					),	
				"page" => array(
					"card" => "many"
					),
				"todo" => array(
					"card" => "many"
					),
				"link" => array(
					"card" => "many"
					),
				"file" => array(
					"card" => "many"
					),
				"event" => array(
					"card" => "many"
					)					
				),
			"page" => array(
				"page" => array(
					"card" => "many"
					),
				"file" => array(
					"card" => "many"
					),
				"todo" => array(
					"card" => "many"
					),
				"link" => array(
					"card" => "many"
					),
				"folder" => array(
					"card" => "many"
					),
				"event" => array(
					"card" => "many"
					)			
				),
			"link" => array(
				"page" => array(
					"card" => "many"
					),
				"file" => array(
					"card" => "many"
					),
				"todo" => array(
					"card" => "many"
					),
				"link" => array(
					"card" => "many"
					),
				"folder" => array(
					"card" => "many"
					),
				"event" => array(
					"card" => "many"
					)			
				),
			"project" => array(
				"db" => array(
					"card" => "many"
					),
				"folder" => array(
					"card" => "many"
					),
				"todo" => array(
					"card" => "many"
					),
				"page" => array(
					"card" => "many"
					),
				"file" => array(
					"card" => "many"
					),
				"link" => array(
					"card" => "many"
					),
				"event" => array(
					"card" => "many"
					)							
				),
			"folder" => array(
				"pform" => array(
					"card" => "many"
					),
				"project" => array(
					"card" => "many"
					),
				"folder" => array(
					"card" => "many"
					),	
				"page" => array(
					"card" => "many"
					),
				"todo" => array(
					"card" => "many"
					),
				"link" => array(
					"card" => "many"
					),
				"file" => array(
					"card" => "many"
					),
				"event" => array(
					"card" => "many"
					)
				),
			"todo" => array(
				"todo" => array(
					"card" => "many"
					),
				"folder" => array(
					"card" => "many"
					),	
				"page" => array(
					"card" => "many"
					),				
				"link" => array(
					"card" => "many"
					),
				"file" => array(
					"card" => "many"
					),
				"event" => array(
					"card" => "many"
					)
				),
			"event" => array(
				"todo" => array(
					"card" => "many"
					),
				"folder" => array(
					"card" => "many"
					),	
				"page" => array(
					"card" => "many"
					),				
				"link" => array(
					"card" => "many"
					),
				"file" => array(
					"card" => "many"
					),
				"event" => array(
					"card" => "many"
					)
				)
		);
		
		$CI =& get_instance();
        $CI->load->library('form');
        $this->form =& $CI->form;
        $CI->load->library('cdata_user');
        $this->user =& $CI->cdata_user;        
        $this->config =& $CI->config;
        $this->rootClass = "root";
	}
	
	function get_child_class_array($objclass){
		$r = array();		
		foreach($this->model[$objclass] as $key => $prop){
			$id = $key;
			$label = $this->object_table[$key]["name"];
			$r[$id] = $label; 
		}
		return $r;
	}
	
	function get_child_class_select($objclass, $name = "child_select"){
		$c = $this->get_child_class_array($objclass);
		$r = $this->form->utils_generate_select($c, $name);
		$tabs = "";
					
		return $r;
	}
	
	
	function getChildCount($pclass, $pid, $class){
		
		$table = $this->object_table[$class]["table"];
		$q = "SELECT COUNT(*) AS tot FROM $table WHERE pclass = '$pclass' AND pid = $pid";
		$res = mysql_fetch_assoc(mysql_query($q));
		return  $res["tot"];		
	}
	
	
	function getChildInterface($oclass = "root", $id = "0"){
		$c = $this->get_child_class_array($oclass);
		//$select = $this->form->utils_generate_select($c, $name);
		$tabs = "";
		$k = 1;
		foreach($c as $class => $label){
			$sel = "";
			$tot = $this->getChildCount($oclass, $id, $class);
			if($k == 1){$sel = " class=\"selected\" "; $k++;}
			$tabs .= "<li $sel><a href=\"#$class\"><em>$label [$tot]</em></a></li>";		
		}
		$iframes = "";
		$childUrlBase = site_url("");
		$CI =& get_instance();
		
		foreach($c as $class => $label){	
			$CI->load->model($class."model");
			$list = $CI->{$class."model"}->grid($oclass, $id);
			$iframes .= "
				<div id=\"$class\">
					<p><input type=\"button\" value=\"Add\" 
						onClick=\"location.href = '{$childUrlBase}/{$class}/xcreate/{$oclass}/{$id}';\"/>
					</p>
					<p>
						$list
					</p>               
	            </div>";	
		}
					
		$if = "
                <div id=\"childTab\" class=\"yui-navset\">
                        <ul class=\"yui-nav\">
                			$tabs                
                        </ul>
                        <div class=\"yui-content\">
                            $iframes                                 
                        </div>
                </div>
                <script>
                (function() {
                        var childTab = new YAHOO.widget.TabView('childTab');
                    })();
                </script> 
                ";	
         return $if;
          
	}
	
	function get_classid($class){
		return $this->object_table[$class]["id"];
	}
	
	function get_class($classid){
		foreach($this->object_table as $key => $prop){
			if($prop["id"] == $classid){
				return $key;
				break;
			}
		}
	}
	
	function add_data($pclass, $pid, $cclass, $cid){
		if($pclass > ""){
			$pclassid = $this->get_classid($pclass);
		} else {
			$pclassid = 0;
		}
		if($cclass > ""){
			$cclassid = $this->get_classid($cclass);
		} else {
			$cclassid = 0;
		}
		if(!isset($pid)){
			$pid = 0;
		}
		$q = "INSERT INTO relationship SET 
			pclassid = $pclassid,
			pid = $pid,
			cclassid = $cclassid,
			cid = $cid
			";
		mysql_query($q);	
	}
	
	// return an array with all parent nodes until root
	function getBreadcrumb($class = "root", $id = "0"){
		if($class == "root"){
			return "> <a href=\"".site_url("root/xview/0")."\">Root</a>";
		}
		list($pclass, $pid, $name) = $this->getParentNode($class,$id);
		$p = " > <a href=\"#\">$name</a>";
		$class = $pclass; $id = $pid;		
		while ($class <> $this->rootClass){
			list($pclass, $pid, $name) = $this->getParentNode($class,$id);		
			$p = " > <a href=\"".site_url("$class/xview/$id")."\">$name</a>" . $p;
			$class = $pclass; $id = $pid;			 
		} 
		$p = "> <a href=\"".site_url("root/xview/0")."\">Root</a>" . $p;	
		return $p;
	}
		
	function getParentNode($class, $id){
		if(!$class > "" or !$id > ""){
			return array("root", 0, "Root");
		} 
		$title = $this->object_table[$class]["pathName"];
		$q = "SELECT pclass, pid, $title FROM {$this->object_table[$class]["table"]} 
		WHERE {$this->object_table[$class]["id"]} = $id";
		$r = mysql_fetch_array(mysql_query($q));
		return array($r["pclass"], $r["pid"], stripslashes($r[$title])); 
	}
	
	function getFirstParent($sClass, $sId, $pClassF){
		list($pclass, $pid, $title) = $this->getParentNode($sClass, $sId);
		while ($pclass <> "root"){
			if($pclass == $pClassF){
				return array($pclass, $pid, $title);
			}
			list($pclass, $pid, $title) = $this->getParentNode($pclass, $pid);
		}
		return false;
	}
	
	function getViewData($class = "root" , $id = "0"){
		$r = array();
		$r["id"] = $id;
		$r["class"] = $class;
		$r["breadcrumb"] = $this->getBreadcrumb($class, $id);
		$r["childInterface"] = $this->getChildInterface($class, $id);
		return $r;
	}
	
	function bookmark($pclass = "root", $pid = "0"){
				
		$user_id = $this->user->get_user_id();
		//checking if it exist already
		$q = "SELECT bookmark_id FROM bookmark WHERE pclass='$pclass' AND pid=$pid AND user_id = $user_id";
		$res = mysql_query($q);
		if (mysql_num_rows($res)>0){print "Bookmark already present!"; exit;}
		// adding bookmark
        list($cl, $id, $name) = $this->getParentNode($pclass,$pid);
        $title = mysql_real_escape_string( "<a href=\"javascript: ajax.open('$pclass','$pid')\">$name</a>");
        $date = $this->form->utils_datetime_to_sql(date("d-m-Y H:i:s"));
        $type = $this->object_table[$pclass]["name"];
        $q = "INSERT INTO bookmark SET 
		pclass = '$pclass',
		pid = $pid,
		user_id = $user_id,
		title = '$title',
		type = '$type',
		created = $date
		";
        if( mysql_query($q)) {
        	print "Bookmark added!";
        } else {
        	print "Error saving data $q";        
        }
	}
	
	
	function delete($class, $id){
		foreach ($this->object_table as $key => $prop) {
			$tid = $prop["id"];
			$tname = $prop["table"];
			$tclass = $key;
			$q = "SELECT $tid FROM $tname WHERE pclass = '$class' AND pid = $id";
			$res = mysql_query($q);
			while($r = mysql_fetch_assoc($res)){
				$this->delete($tclass, $r[$tid]);
			}		
		}
		// delete bookmark
		$q = "DELETE FROM bookmark WHERE pclass = '$class' AND pid = $id";
		mysql_query($q);	
		/*
		$fid = $this->object_table[$class]["id"];
		$tn =  $this->object_table[$class]["table"];
		$q = "DELETE FROM $tn WHERE $fid = $id";
		*/
		//unlink file
		if($class == "file"){
			unlink($this->config->item("fileDir").$id);	
		}
		mysql_query($q);	
		// delete subscription
		$q = "DELETE FROM subscription WHERE pclass = '$class' AND pid = $id";
		mysql_query($q);	
		$fid = $this->object_table[$class]["id"];
		$tn =  $this->object_table[$class]["table"];
		$q = "DELETE FROM $tn WHERE $fid = $id";
		//unlink file
		if($class == "file"){
			@unlink($this->config->item("fileDir").$id);	
		}
		mysql_query($q);			
	}
	
	function log($type = null, $class=null, $id=0, $action=null, $user=0, $message=null){
		$date =  $this->form->utils_datetime_to_sql(date("d-m-Y H:i:s"));	
		$q = "INSERT INTO log SET type = '$type', class = '$class', id = $id, 
		action = '$action', user_id = $user, message = '$message', created = $date";
		mysql_query($q);
		// notify users
		if($action == "add" OR $action == "edit"){
			$users = $this->subscriptionUsers($class, $id);
			$txtclass = $this->object_table[$class]["name"];
			$smessage  = "<b>Subscription notification</b><br/><br/>";
			$smessage .= "<b>Operation</b>:$action<br/>";
			$smessage .= "<b>Content</b>:$txtclass<br/>";
			$smessage .= "<b>Title</b>:$message<br/>";
			$smessage .= "<b><a href=\"".site_url("$class/xview/$id")."\">Link</a></b><br/>";
			$this->notifyUsers($users, "Subscription Notification",$smessage );
		}		
	}
	
	
	function subscriptionUsers($class, $id){
		
		$CI =& get_instance();
		$CI->load->model('subscriptionmodel');
        $this->subscription =& $CI->subscriptionmodel;
        //notify this node subscriptions
        $users = array();
        $users = $this->subscription->usersNode($class, $id);		
		while ($class <> $this->rootClass){
			list($pclass, $pid, $name) = $this->getParentNode($class,$id);		
			$users = array_merge($users, $this->subscription->usersNode($pclass, $pid, "1"));
			$class = $pclass; $id = $pid;			 
		} 
		return $users;       
		
	}
	
	
	function notifyUsers($users, $subject, $message){
		
		if (sizeof($users)==0){
			return;
		}
		$CI =& get_instance();
		$config['mailtype'] = 'html';
		$CI->load->library('email');	
		$CI->email->initialize($config);	
		$fromEmail = $CI->config->item("app_email");
		$fromName = $CI->config->item("app_email_name");		
		$CI->email->subject($CI->config->item("cdata_website_name").": $subject");
		$CI->email->message($message);
		$CI->email->from($fromEmail, $fromName);
		foreach($users as $userid){
			$email = $this->user->get_user_email($userid);
			$CI->email->to($email);
			$CI->email->send();		
		}
			
	}
	
	function nodeExist($class, $id){

		$fid = $this->object_table[$class]["id"];
		$tn =  $this->object_table[$class]["table"];
		$q = "SELECT $fid FROM $tn WHERE $fid = $id";
		$rs = mysql_query($q);
		if (mysql_num_rows($rs)>0){
			return true;
		} else {
			return false;
		}
				
	}
	
	
	function changeParent($class, $id, $pclass, $pid){

		$fid = $this->object_table[$class]["id"];
		$tn =  $this->object_table[$class]["table"];
		$q = "UPDATE $tn SET pclass = '$pclass', pid = $pid WHERE $fid = $id";
		$rs = mysql_query($q);
				
	}
	
	
}
// end class

?>