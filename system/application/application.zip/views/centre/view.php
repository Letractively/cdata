
  <div>

    <h2>Centre</h2>


    <?php echo $this->form->generate_view();?>
    
    <p>
    <input type="button" value="Edit" onClick="location.href = '<?=site_url("centre/edit/$id");?>';"/>
    <input type="button" value="Delete" onClick="checkDelete('<?=site_url("centre/delete/$id");?>', true);"/>
    </p>  
  </div>
