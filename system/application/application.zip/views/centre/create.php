
  <div>

    <h2>Add Centre</h2>


    <?php echo $this->form->generate_form();?>
       
  </div>
