<h2>Centres</h2>
<input type="button" value="Add" onClick="location.href = '<?=site_url("centre/create");?>';"/>
    <?php echo $grid;?>
    
    