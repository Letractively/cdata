
    
<h2>ToDo List</h2>
<p>
    <?php echo $search;?>
</p>
<p>
    <?php echo $grid;?>
</p>
    
    