<h2>Edit Lookup Table</h2>
<?php echo $this->form->generate_form();?>

