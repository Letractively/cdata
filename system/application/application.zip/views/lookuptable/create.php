<h2>Add Lookup Table</h2>


    <?php echo $this->form->generate_form();?>
       