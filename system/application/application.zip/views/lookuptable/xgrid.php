<h2>Lookup Table list</h2>


    <?php echo $search;?>
    
<p>
<input type="button" onclick="document.location = '<?=site_url("lookuptable/create"); ?>'" value="Add New Table"/>
    <?php echo $grid;?>
    
</p> 