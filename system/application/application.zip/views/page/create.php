<h2>Add Page</h2>
<?=$form;?>

