<h2>Edit Page</h2>
<?=$edit;?>