<h2>User Groups</h2>
<input type="button" onClick="location.href=('<?=site_url('usergroup/create');?>')" value="Add" />
    <?php echo $grid;?>
    
    