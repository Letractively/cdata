
    <h2>Edit Centre</h2>


    <?php echo $this->form->generate_form();?>

