    <h2>Add Group</h2>


    <?php echo $this->form->generate_form();?>
       
