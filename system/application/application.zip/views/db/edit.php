<h2>Edit Database</h2>
<p>
<?=$edit;?>
</p>
