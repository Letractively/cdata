<?=$breadcrumb;?>
<h2>Form</h2>
<?=$view;?>
<p>
<input type="button" value="Edit" onClick="location.href = '<?=site_url("pform/edit/$id");?>';"/>
<input type="button" value="Delete" onClick="checkDelete('<?=site_url("pform/delete/$id");?>', true);"/>
<input type="button" value="Move" onClick="location.href = '<?=site_url("admin/move/pform/$id");?>';"/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="button" value="Bookmark" onClick="bookmark.submit('<?=site_url("bookmark/create/pform/$id");?>');"/>
<input type="button" value="Subscribe" onClick="location.href = '<?=site_url("subscription/create/$class/$id");?>';"/>
</p> 
<?=$childInterface;?>
