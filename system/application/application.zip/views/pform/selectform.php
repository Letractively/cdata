<h2>Select form</h2>

<?=$form;?>
