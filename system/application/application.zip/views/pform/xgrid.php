<h2>Forms list</h2>


    <?php echo $search;?>
    
<p>

    <?php echo $grid;?>
    
</p> 