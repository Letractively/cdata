<?php echo $this->form->generate_view();?>
<input type="button" value="Delete" onClick="parent.location.href = '<?=site_url("$class/delete/$id");?>';"/>

