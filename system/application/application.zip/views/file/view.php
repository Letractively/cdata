    <?php echo $this->form->generate_view();?>
    
    <p>
    <input type="button" value="Edit" onClick="location.href = '<?=site_url("$class/edit/$id");?>';"/> 
    <input type="button" value="Delete" onClick="checkDelete('<?=site_url("$class/delete/$id");?>', true);"/>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="button" value="Bookmark" onClick="bookmark.submit('<?=site_url("bookmark/create/file/$id");?>');"/>
    </p> 