
  <div>

    <h2>Add Permission</h2>


    <?php echo $this->form->generate_form();?>
       
  </div>
