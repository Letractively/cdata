
  <div>

    <h2>Edit Permission</h2>


    <?php echo $this->form->generate_form();?>
       
  </div>
