
  <div>

    <h2>Permission</h2>


    <?php echo $this->form->generate_view();?>
    
    <p>
    <?php echo anchor("permission/edit/".$id,"Edit"); ?>
    </p>  
  </div>
