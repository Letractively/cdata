<h2>Forms list</h2>


    <?php echo $search;?>
    
<p>
<input type="button" onclick="document.location = '<?=site_url("cdform/create"); ?>'" value="Add New Form"/>
    <?php echo $grid;?>
    
</p> 