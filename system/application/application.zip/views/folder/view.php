<?php echo $this->form->generate_view();?>
<p>
<input type="button" onClick="location.href=('<?=site_url('folder/edit/')."/$id";?>')" value="Edit" />
<input type="button" onClick="checkDelete('<?=site_url('folder/delete/')."/$id";?>', true)" value="Delete" />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="button" value="Bookmark" onClick="bookmark.submit('<?=site_url("bookmark/create/folder/$id");?>');"/>
</p> 
