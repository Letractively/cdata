<h2>Search page</h2>


    <?php echo $search;?>
    
<h2>List</h2>

    <?php echo $grid;?>

    
    