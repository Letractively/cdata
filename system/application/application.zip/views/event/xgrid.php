<h2>Events</h2>

    <?php echo $grid;?>

    
    