<h2>New Event</h2>
<?=$form;?>

