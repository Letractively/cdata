<h2>Edit Event</h2>
<?=$edit;?>