<h2>Project List</h2>
<?php echo $search;?>
<p>
    <?php echo $grid;?>
</p>

    
    