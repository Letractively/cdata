<p>
    <?php echo $list;?>
    
</p>
    
    