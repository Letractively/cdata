  <div>

    <h2>Login</h2>


    <?php echo $this->form->generate_form();?>
       
  </div>
