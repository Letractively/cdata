<h2>Search user</h2>


    <?php echo $search;?>
    
<h2>User List</h2>

    <?php echo $grid;?>
    
    