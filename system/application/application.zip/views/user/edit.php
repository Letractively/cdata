
  <div>

    <h2>Edit user</h2>


    <?php echo $this->form->generate_form();?>
       
  </div>
