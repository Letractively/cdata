
  <div>

    <h2>Add user</h2>


    <?php echo $this->form->generate_form();?>
       
  </div>
