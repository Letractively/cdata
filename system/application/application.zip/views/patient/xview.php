<?=$breadcrumb;?>
<h2>Patient</h2>
<?=$view;?>
<p>
<input type="button" onClick="location.href=('<?=site_url('patient/edit/')."/$id";?>')" value="Edit" />
<input type="button" onClick="checkDelete('<?=site_url('patient/delete/')."/$id";?>', true)" value="Delete" />
<input type="button" value="Move" onClick="location.href = '<?=site_url("admin/move/patient/$id");?>';"/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="button" value="Bookmark" onClick="bookmark.submit('<?=site_url("bookmark/create/patient/$id");?>');"/>
<input type="button" value="Subscribe" onClick="location.href = '<?=site_url("subscription/create/patient/$id");?>';"/>
</p> 
<?=$childInterface;?>