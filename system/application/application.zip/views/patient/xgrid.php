<h2>Search</h2>
    <?php echo $search;?>
<h2>List</h2>
    <?php echo $grid;?>
<p>
    <input type="button" value="New Registration" onClick="parent.location.href = '<?=site_url("patient/xcreate");?>';"/>
</p>
    
    