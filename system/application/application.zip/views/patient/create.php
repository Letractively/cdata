<h2>New Patient</h2>
<?=$form;?>
