<?=$breadcrumb;?>
<p>
<?=$page;?>
</p>
<?=$childInterface;?>