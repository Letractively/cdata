
  <div>

    <h2>Edit Role</h2>


    <?php echo $this->form->generate_form();?>
       
  </div>
