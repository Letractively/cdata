<?php
/*
 * Created on 20-8-2007
 *
 */


class Db extends Controller {
	
	
	var $object = "db";	
	var $permission_object = "db";
		
	
	
	function Db()
	{	
		parent::Controller();
		$this->load->library("cdata_user");
		$this->load->library("layout");
		$this->load->library("relation");
		$this->load->model("dbmodel");
		
	}
	
	// default page
	function index()
	{			
		redirect ($this->object."/xgrid");
	}
	
	
	function xgrid($page = 1){		
		$this->cdata_user->check_permission($this->permission_object, "list");
		$data = array();
		$data['search'] = $this->dbmodel->search($page);
		$data['grid'] = $this->dbmodel->grid(null, null, $page);
		$this->layout->main = $this->load->view($this->object."/grid",$data,true);		
		$this->layout->render_page();
		
	}
	
	function xcreate($pclass = "root", $pid = "0"){    

		$this->cdata_user->check_permission($this->permission_object, "add");
		$data["form"] = $this->dbmodel->create($pclass, $pid);
		$this->layout->main = $this->load->view($this->object."/create",$data,true);		
		$this->layout->render_page();
		
	}
	
	
	function edit($id){
		
		$this->cdata_user->check_permission($this->permission_object, "edit");
		$data["edit"] = $this->dbmodel->edit($id);
		$this->layout->main = $this->load->view($this->object."/edit",$data,true);		
		$this->layout->render_page();
		
	}

	
	function xview($id){
        
		$this->cdata_user->check_permission($this->permission_object, "view");
		$data = array();
		$data["view"] = $this->dbmodel->view($id);
		$data = array_merge($data, $this->relation->getViewData($this->object, $id));
		$this->layout->main = $this->load->view($this->object."/xview",$data,true);		
		$this->layout->render_page();
		
	}
	
	
	function delete($id){
		
		$this->cdata_user->check_permission($this->permission_object, "delete");
		$this->dbmodel->delete($id);	

	}
	
}


?>