<?php
/*
 * Created on 20-8-2007
 *
 */


class Stat extends Controller {
		
	
	
	function Stat()
	{	
		
		parent::Controller();
		$this->load->library("form");
		$this->load->library("cdata_user");
		$this->load->library("layout");
		$this->load->library("relation");		
		
	}
	
	// default page
	function index()
	{			
		
		$this->sys();
		
		
	}
	
	
	function sys(){
		
		$this->cdata_user->check_permission("app", "access");
		$modules = $this->relation->object_table;
		$stat = array();
		foreach ($modules as $key => $prop){
			$tid = $prop["id"];
			$tname = $prop["table"];
			$tclass = $key;
			$name = $prop["name"];
			$stat[$key] = array();
			$stat[$key]["name"] = $name;
			// tot recs
			$q = "SELECT COUNT(*) AS tot FROM $tname";
			$res = mysql_query($q);			
			$r = mysql_fetch_assoc($res);
			$stat[$key]["tot"] =  $r["tot"];					
		}
		
		$data["stat"] = $stat;
		$this->layout->main = $this->load->view("stat/sys_summary", $data, true);	
		$this->layout->render_page();
		
	}
	
	
	
	
}


?>