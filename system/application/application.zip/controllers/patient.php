<?php
/*
 * Created on 20-8-2007
 *
 */


class Patient extends Controller {
	
	
	var $object = "patient";	
	var $permission_object = "patient";
		
	
	
	function Patient()
	{	
		
		parent::Controller();
		$this->load->library("form");
		$this->load->library("cdata_user");
		$this->load->library("layout");
		$this->load->library("relation");
		$this->load->model("patientmodel");		
		
	}
	
	// default page
	function index()
	{			
		redirect ($this->object."/xgrid");
	}
	
	
	function xgrid($page = 1){
		
		$this->cdata_user->check_permission($this->permission_object, "list");
		$data['grid'] = $this->patientmodel->grid(null, null, $page);
		$this->layout->main = $this->load->view($this->object."/xgrid", $data, true);	
		$this->layout->render_page();
		
	}
	
	
	function xcreate($pclass = "root", $pid = "0"){    

		$this->cdata_user->check_permission($this->permission_object, "add");
		$data["form"] = $this->patientmodel->create($pclass, $pid);
		$this->layout->main = $this->load->view($this->object."/create",$data,true);		
		$this->layout->render_page();
		
	}
	
	
	function edit($id){
		
		$this->cdata_user->check_permission($this->permission_object, "edit");
		$data["edit"] = $this->patientmodel->edit($id);
		$this->layout->main = $this->load->view($this->object."/edit",$data,true);		
		$this->layout->render_page();
	}
	
	
	function cdform_list(){
		
		$q = "SELECT cdform_id, CONCAT(name, ' v.', version) as label FROM cdform ORDER BY name ASC, version DESC";
		$rows = mysql_query($q);
		$r = array();
		while ( $row = mysql_fetch_assoc($rows)){
			$r[$row["cdform_id"]] = $row["label"];
		}
		return $r;
	}

		
	function xview($id){
        				
		$this->cdata_user->check_permission($this->permission_object, "view");	
		$data = array();
		$data["view"] = $this->patientmodel->view($id);
		$data = array_merge($data, $this->relation->getViewData("patient", $id));
		$this->layout->main = $this->load->view($this->object."/xview", $data, true);
		$this->layout->render_page();
	}
	
	
	function delete($id){
		
		$this->cdata_user->check_permission($this->permission_object, "delete");
		$this->patientmodel->delete($id);	
		
	}
	
}


?>